module.exports = {
  base_url: "https://api.liuxia8.cn/hades_appserver/",
  //base_url: "http://192.168.1.4:8081/hades_appserver/",  // test
  //  base_url: "http://localhost:8081/hades_appserver/", // localhost
  token: wx.getStorageSync("token") || "",
  appid: "wx08ab0a41d5663193"

}