//app.js
const config = require("./utils/config.js");
const network = require('./utils/network.js')
App({
  onLaunch: function () {
    //调用API从本地缓存中获取数据
    var logs = wx.getStorageSync('logs') || []

  },
  requestApi(path, params, message, success) {
    // console.log(params);
    var that = this;
   var url = config.base_url + path;
     //var url = path;
    params.appid = that.globalData.appid;
    params.verApp = that.globalData.version;
    var userInfo = wx.getStorageSync("userInfo")
    if (userInfo != null) {
      params.userId = userInfo.userId;
      params.token = userInfo.token
    }
    network.request(url, params, message, {
      'content-type': 'application/x-www-form-urlencoded', // 默认值
      'token': '6d82ab3452b526805ca7897646efd4ea',
      'platformid': '3',
      'packageid': '12',
      'version': '6',
    }, success, function (res) {
    });
  },
  // 网路请求
  ajx(url, data = {}, option = {}) {
    return new Promise((resolve, reject) => {
      if (ajaxNum <= 0) {
        wx.showLoading({
          title: '加载中',
          mask: true
        });
        wx.showNavigationBarLoading();
      }
      ajaxNum++;
      wx.request({
        url: config.base_url + url, //仅为示例，并非真实的接口地址
        header: {
          'content-type': 'application/json' // 默认值
        },
        method: option.type ? option.type : 'GET',
        data: data,
        success(res) {
          resolve(res)
        },
        fail(err) {
          reject(err);
          wx.showModal({
            title: '提示',
            content: '网络错误',
            showCancel: false
          });

        },
        complete: () => {
          ajaxNum = ajaxNum - 1;
          if (ajaxNum <= 0) {
            wx.hideLoading();
            wx.hideNavigationBarLoading();
          }
        }
      })
    })
  },
  getUserInfo: function (cb) {
    var that = this
    if (this.globalData.userInfo) {
      typeof cb == "function" && cb(this.globalData.userInfo)
    } else {
      //调用登录接口
      wx.login({
        success: function () {
          wx.getUserInfo({
            success: function (res) {
              that.globalData.userInfo = res.userInfo
              typeof cb == "function" && cb(that.globalData.userInfo)
            }
          })
        }
      })
    }
  },
  globalData: {
    userInfo: null,
    appid: config.appid,
    version: '1.0',
  }
})