// pages/playing/playing.js
const AV = require("../../libs/av-weapp-min");
var app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    name: '测试',
    url: '',
    imageUrl: '',
    animationData: {},
    isPlay: false,
    thePosition: 0,
    angle: 0,
    cur: '03:44',
    duration: '05:66',
    audioArr: [
    ],
    intervalState: null
  },
  //返回到清单页
  backIndex: function () {
    wx.navigateTo({
      url: '../index/index',
    });
    app.globalData.angle = this.data.angle;
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    //加载传递过来的参数
    var that = this;
    //加载页面时执行播放动作
    that.getList();
  },
  getList: function () {
    var that = this
    app.requestApi("sleep/voice", {
    }, "", function (res) {
      var audio = res.appdata.list[0];
      console.log(audio)
      that.setData({ //如果在sucess直接写this就变成了wx.request()
        audioArr: res.appdata.list,
        url: audio.musicurl,
        imageUrl: encodeURI(audio.resurl),
        isPlay: true
      })
      wx.playBackgroundAudio({
        dataUrl: audio.musicurl,
      })
    })
  },
  //播放/暂停
  play: function () {
    const backgroundAudioManager = wx.getBackgroundAudioManager();
    var theTime;
    var allTime;
    if (this.data.isPlay) {
      wx.pauseBackgroundAudio();
      theTime = backgroundAudioManager.currentTime;
      allTime = backgroundAudioManager.duration;
      console.log("theTime:" + theTime);
      console.log("allTime:" + allTime);
      var theString1 = theTime.toFixed(0);
      var theInt1 = parseInt(theString1);
      var m1 = theInt1 / 60;
      var mString1 = m1.toFixed(0);
      var mInt1 = parseInt(mString1);
      var s1 = theInt1 % 60;
      if (s1 < 10) {
        s1 = "0" + s1;
      }
      var cur = mInt1 + ":" + s1;
      var theString = allTime.toFixed(0);
      var theInt = parseInt(theString);
      var m = theInt / 60;
      var mString = m.toFixed(0);
      var mInt = parseInt(mString);
      var s = theInt % 60;
      var all = mInt + ":" + s;
      this.setData({
        playOrStopUrl: "https://res.psy-1.com/cosleep/miniapp/478%E4%BF%83%E7%9C%A0%20-%20%E7%9D%A1%E5%89%8D%E5%91%BC%E5%90%B8%E6%B3%95.jpg",
        isPlay: false,
        thePosition: theTime,
        duration: all,
        cur: cur
      });
    } else {
      backgroundAudioManager.seek(this.data.thePosition);
      backgroundAudioManager.play();
      this.setData({
        isPlay: true
      });
    }
  },


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var animation = wx.createAnimation({
      duration: 1000,
      timingFunction: 'step-end',
    })

    this.animation = animation

    // animation.scale(2, 2).rotate(45).step()

    this.setData({
      animationData: animation.export()
    })
    var n = 0;
    //连续动画需要添加定时器,所传参数每次+1就行

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },
  mediaPlay: function (e) {
    console.log("mediaPlay")
    console.log(e.target.dataset)
    var that=this;
    var dataset = e.target.dataset;
    that.setData({ imageUrl: encodeURI(dataset.img), url:dataset.url}
)
    wx.playBackgroundAudio({
      dataUrl: dataset.url,
    })
  },
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})