// pages/breath/detail.js

var app = getApp();
// 秒转化时间

Page({

  /**
   * 页面的初始数据
   */
  data: {
    detail: {},
    innerAudioContext: "",
    timer:null,
    isanimation:false,
    currentindex:0
  },
  // 关闭
  close: function () {
 

    var that = this;
    clearInterval(that.data.timer)
    this.setData({
      isanimation: false
    })
    var innerAudioContext = that.data.innerAudioContext;
    innerAudioContext.destroy();
    wx.navigateBack();
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    console.log(options)
    var that = this
    var innerAudioContext = wx.createInnerAudioContext();
    app.requestApi("sleep/breath/detail", {
      "prepare_id": options.id
    }, "", function(res) {
      var arr = res.appdata.prepare_breath.split(/\n/).map((itme,index)=>{
        var length = itme.length - 1
        return itme.slice(1, length).split(',')
      })
      res.appdata.prepare_breath = arr
      that.setData({ //如果在sucess直接写this就变成了wx.request()
        detail: res.appdata,
        innerAudioContext: innerAudioContext
      })
      that.registerAudioContext();
    })
  },
  // 注册音频
  //https://www.jianshu.com/p/c6310af79df8
  registerAudioContext: function() {
    var that = this;
    var innerAudioContext = that.data.innerAudioContext;
    innerAudioContext.autoplay = true;
    innerAudioContext.src = that.data.detail.prepare_cadence;
    innerAudioContext.onCanplay((e) => {
      innerAudioContext.duration;
      setTimeout(() => {
        // console.log(innerAudioContext.duration)//2.795102 时间为秒
        console.log(Math.floor(innerAudioContext.duration))
        let total = Math.floor(innerAudioContext.duration)
        let num = 0, currentindex=0;
        that.data.timer=setInterval(() => {
          total--;
          num ++;
          if ((num-3)==0){
            num=0;
            currentindex++
            this.setData({
              total: getDateStr(total),
              currentindex: currentindex
            })
          }else{
            this.setData({
              total: getDateStr(total)
            })
          }
       
        }, 1000)
        function getDateStr(seconds) {
          var date = new Date(seconds * 1000)
          var year = date.getFullYear();
          var month = date.getMonth() + 1;
          var day = date.getDate();
          var hour = date.getHours() < 10 ? "0" + date.getHours() : date.getHours();
          var minute = date.getMinutes() < 10 ? "0" + date.getMinutes() : date.getMinutes();
          var second = date.getSeconds() < 10 ? "0" + date.getSeconds() : date.getSeconds();
          var currentTime = minute + ":" + second;
          return currentTime
        }
      }, 1000)
    })
    innerAudioContext.onPlay(() => {
      console.log('录音播放中');
      this.setData({
        isanimation:true
      })

    })
    innerAudioContext.onEnded((res) => {
      clearInterval(that.data.timer)
      this.setData({
        isanimation: false
      })

    })
    innerAudioContext.onError((res) => {
      // 播放音频失败的回调
      console.log('播放音频失败' + res);
      clearInterval(that.data.timer)
      this.setData({
        isanimation: false
      })
    })
    innerAudioContext.onStop((res) => {
      console.log('播放结束!');
      clearInterval(that.data.timer)
      this.setData({
        isanimation: false
      })
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {


  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})