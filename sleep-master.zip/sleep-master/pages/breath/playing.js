// pages/playing/playing.js
const AV = require("../../libs/av-weapp-min");
var app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    audioArr: [
    ],
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    //加载传递过来的参数
    var that = this;
    that.getList();
  },
  getList: function () {
    var that = this
    app.requestApi("sleep/breath", {
    }, "", function (res) {
      that.setData({ //如果在sucess直接写this就变成了wx.request()
        audioArr: res.appdata.list,
      })
    })
  },
  

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
    //连续动画需要添加定时器,所传参数每次+1就行

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },
  mediaPlay: function (e) {
    console.log("mediaPlay")
    console.log(e.target.dataset)
    wx.navigateTo({
      url: '../breath/detail?id=' + e.target.dataset.id
    })

  },
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})