// pages/my/index.js

const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    hasUserInfo: false,
    canIUse: wx.canIUse('button.open-type.getUserInfo'),
    userInfo: {}
  },
  copyTap: function () {
    wx.setClipboardData({
      //准备复制的数据
      data: "wozai_com",
      success: function (res) {
        wx.showToast({
          title: '微信号成功复制',
        });
      }
    }
    )
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.initUserInfo();
  },

  initUserInfo: function () {
    var that = this;
    var userInfo = wx.getStorageSync('userInfo');
    if(userInfo!=null&&userInfo.authorize=='1'){
      that.setData({
        userInfo: userInfo,
        hasUserInfo: true
      })
      console.log(1111 +"initUserInfo")
      return;
    }
    if (app.globalData.userInfo) {
      console.log(app.globalData.userInfo)
      this.setData({
        userInfo: app.globalData.userInfo,
        hasUserInfo: true
      })
    } else if (this.data.canIUse) {
      // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
      // 所以此处加入 callback 以防止这种情况
      app.userInfoReadyCallback = res => {
        this.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        })
      }
    } else {
      // 在没有 open-type=getUserInfo 版本的兼容处理
      wx.getUserInfo({
        success: res => {
          app.globalData.userInfo = res.userInfo
          this.setData({
            userInfo: res.userInfo,
            hasUserInfo: true
          })
        }
      })
    }
  },
  getUserInfo: function (e) {
    var that = this;
    console.log(e)
    if (e.detail.errMsg == "getUserInfo:ok") {
      app.globalData.userInfo = e.detail.userInfo
      this.setData({
        userInfo: e.detail.userInfo,
        hasUserInfo: true
      })
      that.ajaxUpdateUserInfo(e.detail.rawData);
    } else {
      console.log(333, '执行到这里，说明拒绝了授权')
      wx.showToast({
        title: "为了您更好的体验,请先同意授权",
        icon: 'none',
        duration: 2000
      });
    }
  },
  ajaxUpdateUserInfo: function (userInfo) {
    var that = this;
    var cache = wx.getStorageSync('userInfo');
    //https://developers.weixin.qq.com/community/develop/doc/da35682d47ec85ad1cdc1fb9c1db8023
    app.requestApi(
      "login/wx/updateUserInfo",
      {
        "userId": cache.userId,
        "appid": app.globalData.appid,
        "token": cache.token,
        "userInfo": userInfo
      },
      "",
      function (res) {
        console.log(res)
        if (res.code == "0000") {
          console.log("完善用户信息成功")
          wx.removeStorage({
            key: 'userInfo',
            success: function (res) {
              app.getUserInfo(function (cb) {
                wx.navigateBack({
                  delta: 1,
                })
              });
            }
          })

        }
      })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },
  page_mypublish: function () {
    wx.navigateTo({
      url: '../my/mypublish'
    })
  },
  page_views: function () {
    wx.navigateTo({
      url: '../my/views'
    })
  },
  aboutFun: function () {
    wx.navigateTo({
      url: '../my/about'
    })
  },
  page_collection: function () {
    wx.navigateTo({
      url: '../my/collection'
    })
  },
  page_myeditinfo: function () {
    wx.navigateTo({
      url: '../my_editinfo/index'
    })
  },
  wx_login: function () {
    // 查看是否授权
    console.log("wx_login")
    wx.getSetting({
      success(res) {
        if (res.authSetting['scope.userInfo']) {
          // 已经授权，可以直接调用 getUserInfo 获取头像昵称
          wx.getUserInfo({
            success: function (res) {
              console.log(res.userInfo)
            }
          })
        }
      }
    })
  },
  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },
})