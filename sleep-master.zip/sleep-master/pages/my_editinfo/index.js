// pages/my_editinfo/index.js
var app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    sexArray: ['请选择', '男', '女'],
    ageArray: ['请选择', '00后', '95后', '90后', '85后', '80后', '80前'],
    sexSelect: '请选择',
    ageSelect: '请选择',
    userInfo: { wechat: "" },
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    var userInfo = wx.getStorageSync("userInfo");
    if (userInfo.gender) {
      that.setData({ sexSelect: userInfo.gender == '1' ? "男" : "女" })
    }
    console.log(userInfo)
    that.setData({ userInfo: userInfo })
  },
  bindPickerChange: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      index: e.detail.value
    })
  },
  bindAgeChange: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      indexAge: e.detail.value
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  formSubmit(e) {
    var that = this;
    console.log('Default Form Submit \n', e.detail.value)
    var userUpdateReq = e.detail.value;
    userUpdateReq.gender = e.detail.value.sex == '男' ? "1" : "2"
    app.requestApi("user/update",
      userUpdateReq
      , "", function (res) {
        var obj = Object.assign(that.data.userInfo, userUpdateReq);
        that.setData({ //如果在sucess直接写this就变成了wx.request()
          userInfo: obj,
        })
        console.log(obj)
        wx.setStorageSync("userInfo", obj)
        wx.navigateBack({})
      })
  },
  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})