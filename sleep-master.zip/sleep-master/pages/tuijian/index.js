// pages/tuijian/index.js
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    audioArr: [],
    music: "",
    name:"",
    innerAudioContext: ""
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    var innerAudioContext = wx.createInnerAudioContext();
    that.setData({ innerAudioContext: innerAudioContext })
    that.getList();
  },

  getList: function () {
    var that = this
    app.requestApi("sleep/recommend", {
    }, "", function (res) {
      that.setData({ //如果在sucess直接写this就变成了wx.request()
        audioArr: res.data,
      })
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },
  onePause:function(){
    var that=this;
    var innerAudioContext = that.data.innerAudioContext;
    innerAudioContext.pause(() => {
      console.log('pause');
    })
  },
  onePlay: function () {
    var that = this;
    var innerAudioContext = that.data.innerAudioContext;
    innerAudioContext.play(() => {
      console.log('play');
    })
  },
  play: function (e) {
    var that = this;
    that.setData({ music: e.target.dataset.music, name: e.target.dataset.name })
    console.log(e.target.dataset)
    console.log("play")
    that.registerAudioContext();
  },
  registerAudioContext: function () {
    var that = this;
    var innerAudioContext = that.data.innerAudioContext;
    innerAudioContext.pause(() => {
      console.log('pause');
    })
    innerAudioContext.autoplay = true;
    innerAudioContext.src = that.data.music;
    innerAudioContext.onPlay(() => {
      console.log('录音播放中');
    })
    innerAudioContext.onEnded((res) => {
      console.log(res)
    })

    innerAudioContext.onError((res) => {
      // 播放音频失败的回调
      console.log('播放音频失败' + res);

    })

    innerAudioContext.onStop((res) => {
      console.log('播放结束!');
    })
  },
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})