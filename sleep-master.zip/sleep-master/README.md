# Little-sleep
小睡眠，一款帮助睡眠的微信小程序

小睡眠。  广州心与潮、。。。指数：4316


https://api.psy-1.com/miniapp/v1/tag/music?tag_id=1&p=0 音乐列表【icon+图片】

https://api.psy-1.com/miniapp/v1/music/tag  标签分类
2：助眠
https://api.psy-1.com/miniapp/v1/music/voice?category_id=1&p=0 分类
https://api.psy-1.com/miniapp/v1/music/voice/category 全部分类
3：呼吸
https://api.psy-1.com/miniapp/v1/sleep/breath
https://api.psy-1.com/miniapp/v1/sleep/breath/detail?prepare_id=2 详情
4：推荐模块
https://api.psy-1.com/miniapp/v1/music/recommend


小睡眠源代码：http://www.wxapp-union.com/thread-4609-1-1.html




蜗牛睡眠。。蔡博龙科技
测睡眠。。。北京康加科技
潮汐睡眠。。。广州多少网络